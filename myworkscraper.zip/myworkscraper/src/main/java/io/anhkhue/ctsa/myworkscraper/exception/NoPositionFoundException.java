package io.anhkhue.ctsa.myworkscraper.exception;

public class NoPositionFoundException extends Exception {
}
