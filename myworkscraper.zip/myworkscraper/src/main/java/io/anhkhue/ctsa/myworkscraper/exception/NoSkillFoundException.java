package io.anhkhue.ctsa.myworkscraper.exception;

public class NoSkillFoundException extends Exception {
}
