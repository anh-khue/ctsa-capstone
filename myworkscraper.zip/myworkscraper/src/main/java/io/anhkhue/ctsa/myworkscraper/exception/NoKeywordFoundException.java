package io.anhkhue.ctsa.myworkscraper.exception;

public class NoKeywordFoundException extends Exception {
}
